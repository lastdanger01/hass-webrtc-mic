import os.path
import platform

import homeassistant.helpers.config_validation as cv
import voluptuous as vol
import yaml
from homeassistant.config_entries import ConfigFlow
from homeassistant.const import CONF_URL, CONF_USERNAME, CONF_PASSWORD

from . import DOMAIN, utils


# links for the user step description (hassfest does not allow URLs inside translations)
USER_PLACEHOLDERS = {
    "go2rtc_url": "https://github.com/AlexxIT/go2rtc",
    "go2rtc_addon_url": "https://github.com/AlexxIT/go2rtc#go2rtc-home-assistant-add-on",
    "frigate_url": "https://docs.frigate.video/",
    "local_url": "http://localhost:1984",
}


class FlowHandler(ConfigFlow, domain=DOMAIN):
    async def async_step_user(self, user_input=None):
        # check if only one integration instance
        if self._async_current_entries():
            return self.async_abort(reason="single_instance_allowed")

        # check if we support this arch
        if not utils.get_arch():
            return self.async_abort(
                reason="arch",
                description_placeholders={"uname": str(platform.uname())},
            )

        if user_input is not None:
            url = user_input.get(CONF_URL)

            # user left the field empty -> auto-detect go2rtc
            if not url:
                detected = await utils.detect_go2rtc(self.hass)
                if detected:
                    return self.async_create_entry(
                        title="WebRTC Camera", data={CONF_URL: detected}
                    )

                # nothing found: ask whether to run a bundled go2rtc
                return self.async_show_form(
                    step_id="user",
                    data_schema=vol.Schema(
                        {
                            vol.Optional(CONF_URL, default=""): cv.string,
                            vol.Optional("bundled_go2rtc", default=False): bool,
                        }
                    ),
                    errors={"base": "connect"},
                    description_placeholders=USER_PLACEHOLDERS,
                )

            if user_input.get("bundled_go2rtc"):
                return self.async_create_entry(
                    title="WebRTC Camera",
                    data={"bundled_go2rtc": True},
                )

            # check if go2rtc url from user input available
            if not await utils.check_go2rtc(self.hass, url):
                return self.async_show_form(
                    step_id="user",
                    data_schema=vol.Schema(
                        {
                            vol.Optional(CONF_URL, default=url): cv.string,
                        }
                    ),
                    errors={"base": "connect"},
                    description_placeholders=USER_PLACEHOLDERS,
                )

            return self.async_create_entry(title="WebRTC Camera", data=user_input)

        # Zero-config path: probe the well-known go2rtc locations. If one
        # answers, create the entry right away - the user never sees a form.
        detected = await utils.detect_go2rtc(self.hass)
        if detected:
            return self.async_create_entry(
                title="WebRTC Camera", data={CONF_URL: detected}
            )

        # Nothing found. Fall back to a form so the user can type a URL.
        url = await utils.check_go2rtc(self.hass) or vol.UNDEFINED

        return self.async_show_form(
            step_id="user",
            data_schema=vol.Schema(
                {
                    vol.Optional(CONF_URL, default=url): cv.string,
                    vol.Optional("bundled_go2rtc", default=False): bool,
                }
            ),
            description_placeholders=USER_PLACEHOLDERS,
        )

    async def async_step_config(self, user_input: dict = None):
        path = self.hass.config.path("go2rtc.yaml")

        if user_input:
            config = {}

            if not user_input["api"]:
                config.setdefault("api", {}).setdefault("listen", "127.0.0.1:1984")

            if not user_input["rtsp"]:
                config.setdefault("rtsp", {}).setdefault("listen", "127.0.0.1:8554")

            if user := user_input.get(CONF_USERNAME):
                config.setdefault("api", {}).setdefault("username", user)
                config.setdefault("rtsp", {}).setdefault("username", user)

            if pasw := user_input.get(CONF_PASSWORD):
                config.setdefault("api", {}).setdefault("password", pasw)
                config.setdefault("rtsp", {}).setdefault("password", pasw)

            if config:
                with open(path, "w") as f:
                    yaml.dump(config, f)

            return self.async_create_entry(title="WebRTC Camera", data={})

        return self.async_show_form(
            step_id="config",
            data_schema=vol.Schema(
                {
                    vol.Required("api", default=True): cv.boolean,
                    vol.Required("rtsp", default=True): cv.boolean,
                    vol.Optional(CONF_USERNAME): cv.string,
                    vol.Optional(CONF_PASSWORD): cv.string,
                }
            ),
            description_placeholders={"path": path},
        )
